package frc.robot.Egg.Utility;

public enum ErrorType {
	Fatal,
	NonFatal,
	Information,
	Temporary;
}
