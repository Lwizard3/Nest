package frc.robot.Egg.Utility;

public enum Constants {
	//If we needs constants defined, they could be put here
	
	

}
