package frc.robot.Egg.Utility.Math;

public class E {
	
	
	public static String Clean(double D) {
		
		String temp = "";
		temp += D;
		
		temp = temp.replaceAll("E", "e^");
				
		return temp;
			
		
	}
	
	
	
	
}
